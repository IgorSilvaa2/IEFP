Em 1.sql, escreve uma consulta SQL para listar os títulos de todos os episódios
na temporada original de Cyberchase, Temporada 1.

SELECT * FROM episodes;
SELECT title, season FROM episodes where season = 1;

10.Em 10.sql, escreve uma consulta SQL para listar os ids, títulos e códigos de
produção de todos os episódios. Ordena os resultados pelo código de produção,
do mais antigo para o mais recente.

select id,tittle,production_code from episodes order by production_code;

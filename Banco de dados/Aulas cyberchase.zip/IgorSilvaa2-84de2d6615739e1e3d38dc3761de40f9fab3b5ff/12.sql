12.sql, conta o número de títulos de episódios únicos.

select count(distinct title) from episodes;

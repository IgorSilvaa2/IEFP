13.Em 13.sql, escreve uma consulta SQL para explorar uma questão à tua escolha.
Esta consulta deve:
▪ Envolver pelo menos uma condição, usando WHERE com AND ou OR

select title from episodes where (season = 1 or season 2) and air_date >= 2007;

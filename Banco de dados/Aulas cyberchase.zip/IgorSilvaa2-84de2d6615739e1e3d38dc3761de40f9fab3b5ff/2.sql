Em 2.sql, lista o número da temporada e o título do primeiro episódio de cada
temporada.

select title, season from  episode where episode_in_season = 1;

Em 3.sql, encontra o código de produção para o episódio “Hackerized!”.

select production_code from episodes where title = 'Hackerized!';

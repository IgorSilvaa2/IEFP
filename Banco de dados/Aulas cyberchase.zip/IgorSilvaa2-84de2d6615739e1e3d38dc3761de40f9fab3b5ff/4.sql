Em 4.sql, escreve uma consulta para encontrar os títulos dos episódios que
ainda não têm um tópico listado.

select title from episodes where topic is null;

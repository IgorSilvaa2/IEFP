Em 5.sql, encontra o título do episódio especial que foi exibido a 31 de
dezembro de 2004.

select title from episodes where air_ate = '2004-12-31';

Em 6.sql, lista os títulos dos episódios da temporada 6 (2008) que foram
lançados antecipadamente, em 2007.

select title from episodes where season = 6 and air_date like'2007%';


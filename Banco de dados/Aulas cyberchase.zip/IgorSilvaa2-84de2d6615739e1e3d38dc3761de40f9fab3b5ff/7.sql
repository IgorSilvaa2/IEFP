Em 7.sql, escreve uma consulta SQL para listar os títulos e tópicos de todos os
episódios que ensinam frações.


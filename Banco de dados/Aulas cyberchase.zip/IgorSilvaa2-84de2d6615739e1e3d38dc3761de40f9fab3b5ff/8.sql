Em 8.sql, escreve uma consulta que conte o número de episódios lançados nos
últimos 6 anos, de 2018 a 2023, inclusive.

select count (*) from episodes where air_date between '2018-01-01' and '2023-12-31;

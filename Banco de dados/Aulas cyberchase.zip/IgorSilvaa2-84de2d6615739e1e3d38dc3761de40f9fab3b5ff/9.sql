Em 9.sql, escreve uma consulta que conte o número de episódios lançados nos
primeiros 6 anos de Cyberchase, de 2002 a 2007, inclusive.

select count(*) from episodes where air_date between '2002-01-01' and '2007-12-31';

